
namespace SimpleTreeContent
{
	// Should subclass MonoMac.AppKit.NSResponder
	[MonoMac.Foundation.Register("AppDelegate")]
	public partial class AppDelegate
	{
	}
}

