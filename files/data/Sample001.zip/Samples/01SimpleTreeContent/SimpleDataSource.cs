using System;
using MonoMac.AppKit;
using MonoMac.Foundation;
using System.Collections.Generic;
using System.Drawing;

namespace SimpleTreeContent
{
	public class SimpleDataSource : NSOutlineViewDataSource
	{
		private Node RootNode {get; set;}
		public SimpleDataSource ()
		{
			RootNode = RootNode = new Node()
			{
				Name = "The root node",
				Children = new List<Node>(),
				IsRoot = true
			};
			
			Node paper;
			RootNode.Children.Add(new Node("Rock"));
			RootNode.Children.Add(paper = new Node("Paper"));
			RootNode.Children.Add(new Node("Scissors"));
			RootNode.Children.Add(new Node("Lizard"));
			RootNode.Children.Add(new Node("Spock"));
			
			paper.Children.Add(new Node("Telegraph"));
			paper.Children.Add(new Node("Times"));
			paper.Children.Add(new Node("Sun"));
			
			
		}
		
		public override int GetChildrenCount (NSOutlineView outlineView, NSObject item)
		{
			Node node =  item as Node;
			return item == null ? 1 : node.Children.Count;
		}
		
		public override NSObject GetChild (NSOutlineView outlineView, int childIndex, NSObject ofItem)
		{
			Node node = ofItem as Node;
			return ofItem == null ? RootNode : node.Children[childIndex];
		}

	
		public override NSObject GetObjectValue (NSOutlineView outlineView, NSTableColumn forTableColumn, NSObject byItem)
		{
			Node f = byItem as Node;			
			return new NSString(f.Name);
		}
				
		public override bool ItemExpandable (NSOutlineView outlineView, NSObject item)
		{
			Node f = item as Node;
			return item == null ? true : f.Children.Count >0;
		}
		
	
	}

	public class Node : NSObject
	{
		public Node ()
		{
			Children = new List<Node>();
		}
		
		public Node (string name) : this()
		{
			Name = name;
		}
		
		public bool IsRoot { get; set; }

		public string Name { get; set; }
		
		public List<Node> Children { get; set; }
	
	}
}